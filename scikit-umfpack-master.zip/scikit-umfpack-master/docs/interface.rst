.. automodule:: scikits.umfpack.interface
