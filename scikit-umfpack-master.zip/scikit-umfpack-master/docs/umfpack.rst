.. automodule:: scikits.umfpack.umfpack
